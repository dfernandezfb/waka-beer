const RegisterPage = () => {
  return ( <p>register</p> );
}
 
export default RegisterPage;