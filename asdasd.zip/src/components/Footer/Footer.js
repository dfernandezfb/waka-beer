const Footer = () => {
  return ( <h2>SOY UN FOOTER</h2> );
}
 
export default Footer;