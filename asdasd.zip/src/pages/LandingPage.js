import Header from "../components/Header/Header";
import LandingMain from "../components/LandingMain/LandingMain";
import Layout from "../components/Layout/Layout";

const LandingPage = () => {
  return (
      <LandingMain/>
  );
}
 
export default LandingPage;