
const Home = () => {
  return (
    <p>Hola, estoy logueado</p>
    );
}
 
export default Home;